-- --------------------------------------------------------
-- Servidor:                     127.0.0.1
-- Versão do servidor:           10.1.21-MariaDB - mariadb.org binary distribution
-- OS do Servidor:               Win32
-- HeidiSQL Versão:              9.1.0.4867
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Copiando estrutura do banco de dados para planoe
DROP DATABASE IF EXISTS `planoe`;
CREATE DATABASE IF NOT EXISTS `planoe` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `planoe`;


-- Copiando estrutura para tabela planoe.aulas
DROP TABLE IF EXISTS `aulas`;
CREATE TABLE IF NOT EXISTS `aulas` (
  `id_aula` int(11) NOT NULL AUTO_INCREMENT,
  `fk_materia` int(11) NOT NULL,
  `aula_nome` char(10) DEFAULT NULL,
  `aula_status` int(1) DEFAULT '0' COMMENT '0 = falta assistir, 1 = incompleta, 2 = concluída',
  `tempo_parada` varchar(50) DEFAULT NULL,
  `resumo` longtext,
  PRIMARY KEY (`id_aula`),
  KEY `FK_Disciplinas` (`fk_materia`),
  CONSTRAINT `FK_Disciplinas` FOREIGN KEY (`fk_materia`) REFERENCES `disciplinas` (`id_disciplinas`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=72 DEFAULT CHARSET=latin1;

-- Copiando dados para a tabela planoe.aulas: ~70 rows (aproximadamente)
/*!40000 ALTER TABLE `aulas` DISABLE KEYS */;
REPLACE INTO `aulas` (`id_aula`, `fk_materia`, `aula_nome`, `aula_status`, `tempo_parada`, `resumo`) VALUES
	(2, 1, 'Aula01', 2, '', ''),
	(3, 1, 'Aula02', 0, '', ' '),
	(4, 1, 'Aula03', 0, '', ''),
	(5, 1, 'Aula04', 0, '', NULL),
	(6, 1, 'Aula05', 0, '', ' '),
	(7, 1, 'Aula06', 0, '', NULL),
	(8, 1, 'Aula07', 0, '', NULL),
	(9, 1, 'Aula08', 0, '', NULL),
	(10, 1, 'Aula09', 0, '', NULL),
	(11, 1, 'Aula10', 0, '', NULL),
	(12, 2, 'Aula01', 2, '20 minutos', ''),
	(13, 2, 'Aula02', 0, '', NULL),
	(14, 2, 'Aula03', 0, '', ' '),
	(15, 2, 'Aula04', 0, '', ''),
	(16, 2, 'Aula05', 0, '', NULL),
	(17, 2, 'Aula06', 0, '', NULL),
	(18, 2, 'Aula07', 0, '', NULL),
	(19, 2, 'Aula08', 0, '', ''),
	(20, 2, 'Aula09', 0, '', NULL),
	(21, 2, 'Aula10', 0, '', ''),
	(22, 3, 'Aula01', 1, '8 Minutos e 30 segundos', NULL),
	(23, 3, 'Aula02', 0, '', NULL),
	(24, 3, 'Aula03', 0, '', NULL),
	(25, 3, 'Aula04', 0, '', NULL),
	(26, 3, 'Aula05', 0, '', NULL),
	(27, 3, 'Aula06', 0, '', NULL),
	(28, 3, 'Aula07', 0, '', NULL),
	(29, 3, 'Aula08', 0, '', NULL),
	(30, 3, 'Aula09', 0, '', NULL),
	(31, 3, 'Aula10', 0, '', NULL),
	(32, 4, 'Aula01', 2, '', ''),
	(33, 4, 'Aula02', 0, '', NULL),
	(34, 4, 'Aula03', 0, '', NULL),
	(35, 4, 'Aula04', 0, '', NULL),
	(36, 4, 'Aula05', 0, '', NULL),
	(37, 4, 'Aula06', 0, '', NULL),
	(38, 4, 'Aula07', 0, '', NULL),
	(39, 4, 'Aula08', 0, '', NULL),
	(40, 4, 'Aula09', 0, '', NULL),
	(41, 4, 'Aula10', 0, '', NULL),
	(42, 5, 'Aula01', 2, '', 'Apenas uma introduÃ§Ã£o do assunto, abordando os tipos de topologias, o que Ã© isp, backbone, tipos de redes, como lan, wan, entre outras.'),
	(43, 5, 'Aula02', 0, '', NULL),
	(44, 5, 'Aula03', 0, '', NULL),
	(45, 5, 'Aula04', 0, '', NULL),
	(46, 5, 'Aula05', 0, '', NULL),
	(47, 5, 'Aula06', 0, '', NULL),
	(48, 5, 'Aula07', 0, '', NULL),
	(49, 5, 'Aula08', 0, '', NULL),
	(50, 5, 'Aula09', 0, '', NULL),
	(51, 5, 'Aula10', 0, '', NULL),
	(52, 6, 'Aula01', 0, '', NULL),
	(53, 6, 'Aula02', 0, '', NULL),
	(54, 6, 'Aula03', 0, '', NULL),
	(55, 6, 'Aula04', 0, '', NULL),
	(56, 6, 'Aula05', 0, '', NULL),
	(57, 6, 'Aula06', 0, '', NULL),
	(58, 6, 'Aula07', 0, '', NULL),
	(59, 6, 'Aula08', 0, '', NULL),
	(60, 6, 'Aula09', 0, '', NULL),
	(61, 6, 'Aula10', 0, '', NULL),
	(62, 7, 'Aula01', 0, '', NULL),
	(63, 7, 'Aula02', 0, '', NULL),
	(64, 7, 'Aula03', 0, '', NULL),
	(65, 7, 'Aula04', 0, '', NULL),
	(66, 7, 'Aula05', 0, '', NULL),
	(67, 7, 'Aula06', 0, '', NULL),
	(68, 7, 'Aula07', 0, '', NULL),
	(69, 7, 'Aula08', 0, '', NULL),
	(70, 7, 'Aula09', 0, '', NULL),
	(71, 7, 'Aula10', 0, '', NULL);
/*!40000 ALTER TABLE `aulas` ENABLE KEYS */;


-- Copiando estrutura para tabela planoe.disciplinas
DROP TABLE IF EXISTS `disciplinas`;
CREATE TABLE IF NOT EXISTS `disciplinas` (
  `id_disciplinas` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(50) NOT NULL,
  `materia_status` int(1) NOT NULL DEFAULT '0' COMMENT '0 = falta cursar, 1 = cursando, 2 = concluída',
  `icon` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id_disciplinas`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

-- Copiando dados para a tabela planoe.disciplinas: ~7 rows (aproximadamente)
/*!40000 ALTER TABLE `disciplinas` DISABLE KEYS */;
REPLACE INTO `disciplinas` (`id_disciplinas`, `nome`, `materia_status`, `icon`) VALUES
	(1, 'MODELAGEM DE DADOS', 1, 'img/dados.png'),
	(2, 'PROBABILIDADE E ESTAT&Iacute;STICAS', 1, 'img/probabilidade.png'),
	(3, 'PROPRIEDADE INTELECTUAL', 1, 'img/inteligencia.png'),
	(4, 'QUALIDADE DE SOFTWARE', 1, 'img/Applications-icon.png'),
	(5, 'REDES DE COMPUTADORES', 1, 'img/lan.png'),
	(6, 'SISTEMAS OPERACIONAIS', 1, 'img/app.png'),
	(7, 'TECNOLOGIAS WEB', 1, 'img/web.png');
/*!40000 ALTER TABLE `disciplinas` ENABLE KEYS */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
